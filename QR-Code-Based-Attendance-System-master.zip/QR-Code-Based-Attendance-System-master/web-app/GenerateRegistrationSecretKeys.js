var regis = require('./registration');
regis.populateAttendanceRegistration('./rollNo.txt')

